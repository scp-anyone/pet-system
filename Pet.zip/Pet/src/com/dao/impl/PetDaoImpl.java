package com.dao.impl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.bean.Pet;
import com.bean.PetStore;
import com.dao.BaseDao;
import com.dao.PetDao;
public class PetDaoImpl extends BaseDao implements PetDao{
	public int insert(Pet pet) {
		int result=0;
		Map<Integer,Pet> map=null;
		try {
			map=(HashMap)this.readObjectFromFile("Pet.dat");
			if(map==null) {
				map=new HashMap();
			}
			map.put(pet.getId(), pet);
			this.writeObjectToFile(map,"Pet.dat");
			result =1;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	public List<Pet> getPetByStoreId(int storeId){
		List<Pet> list =new ArrayList<Pet>();
		Map<Integer,Pet> map=(HashMap<Integer,Pet>) this.readObjectFromFile("Pet pet");
		if(map!=null) {
			for(Map.Entry<Integer,Pet> entry : map.entrySet()) {
				Pet pet=entry.getValue();
				if(pet.getStoreId()==storeId)
					list.add(pet);
			}
		}else {
			System.out.println("�ļ�������!����");
		}
		return list;
	}
}
