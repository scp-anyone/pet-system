package com.dao.impl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.bean.Pet;
import com.bean.PetOwner;
import com.dao.BaseDao;
import com.dao.PetOwnerDao;
public class PetOwnerDaoImpl extends BaseDao implements PetOwnerDao {
	public PetOwner getOwnerById(int ownerId) {
		PetOwner petOwner =null;
		Map<Integer,PetOwner> map=(HashMap) this.readObjectFromFile("PetOwner.dat");
		if(map!=null) {
			petOwner=map.get(ownerId);
		}
		return petOwner;
	}
	public int insert(PetOwner petOwner) {
		int result=0;
		Map map=null;
		try {
			map=(HashMap) this.readObjectFromFile("PetOwner.dat");
			if(map==null) {
				map=new HashMap();
			}
			map.put(petOwner.getId(), petOwner);
			this.writeObjectToFile(map, "PetOwner.dat");
			result=1;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	public int modify(PetOwner petOwner) {
		int result =0;
		Map map=null;
		try {
			map=(HashMap) this.readObjectFromFile("PetOwner.dat");
			if(map!=null) {
				PetOwner pOwner=(PetOwner) map.get(petOwner.getId());
				pOwner.setMoney(petOwner.getMoney());
				map.put(petOwner.getId(), pOwner);
				this.writeObjectToFile(map, "PetOwner.dat");
				result=1;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	public int delete(int ownerId) {
		int result=0;
		Map map=null;
		try {
			map=(HashMap) this.readObjectFromFile("PetOwner.dat");
			if(map==null) {
				map=new HashMap();
			}
			if(map.containsKey(ownerId)) {
				map.remove(ownerId);
				result=this.writeObjectToFile(map,"PetOwner.dat");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	public List<PetOwner> getAllOwner(){
		List<PetOwner> list=new ArrayList<PetOwner>();
		Map<Integer,PetOwner> map=(HashMap) this.readObjectFromFile("PetOwner.dat");
		if(map!=null) {
			for(Map.Entry<Integer,PetOwner> entry:map.entrySet()) {
				list.add(entry.getValue());
			}
		}else {
			System.out.println("�ļ������ڣ�����");
		}
		return list;
	}	
}
