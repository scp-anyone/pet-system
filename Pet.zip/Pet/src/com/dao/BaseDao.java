package com.dao;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
public class BaseDao {
	private OutputStream out=null;
	private InputStream in=null;
	public int writeObjectToFile(Object obj,String fileName) {
		int result =0;
		File file =new File("c:"+File.separator+"pet"+File.separator+fileName);
		ObjectOutputStream objOut=null;
		try {
			out =new FileOutputStream(file);
			objOut =new ObjectOutputStream(out);
			objOut.writeObject(obj);
			result=1;
		}catch(IOException e) {
			System.out.println("write object failed");
			e.printStackTrace();
		}finally {
			if (objOut!=null) {
				try {
					objOut.flush();
					objOut.close();
					out.close();
				}catch(IOException e) {
					System.out.println("�ļ��ر�ʧ�ܣ�");
					e.printStackTrace();
				}
			}
		}
		return result;
	}
	public Object readObjectFromFile(String fileName) {
		Object temp=null;
		File file =new File("c:"+File.separator+"pet"+File.separator+fileName);
		ObjectInputStream objIn=null;
		if (file.exists()) {
			try {
				in =new FileInputStream(file);
				objIn =new ObjectInputStream(in);
				temp=objIn.readObject();
			}catch(IOException e) {
				System.out.println("read object failed");
				e.printStackTrace();
			}catch(ClassNotFoundException e) {
				e.printStackTrace();
			}finally{
				if (objIn!=null) {
					try {
						objIn.close();
						out.close();
					}catch(IOException e) {
						System.out.println("�ļ��ر�ʧ�ܣ�");
						e.printStackTrace();
					}
				}
			}
		}
		return temp;
	}
}
