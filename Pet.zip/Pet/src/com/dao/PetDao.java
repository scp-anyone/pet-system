package com.dao;
import java.util.List;
import com.bean.Pet;
public interface PetDao {
	public int insert(Pet pet);
	public List<Pet> getPetByStoreId(int storeId);
}
