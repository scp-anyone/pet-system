package com.service;
import java.util.List;
import com.bean.Pet;
import com.bean.PetStore;
public interface PetService {
	public int breed(Pet pet,PetStore petStore);
	public List<Pet> getPetByStoreId(int storeId);
}
