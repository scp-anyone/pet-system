
package com.bean;

import java.io.Serializable;
import java.util.Date;

public class Pet implements Serializable{
	private int id;
	private String name;
	private String typeName;
	private int health;
	private int love;
	private Date birthday;
	private int ownerId;
	private int storeId;
	public Pet() {
		super();
	}
	public Pet(int id, String name, String typeName, int health, int love, Date birthday, int storeId) {
		super();
		this.id = id;
		this.name = name;
		this.typeName = typeName;
		this.health = health;
		this.love = love;
		this.birthday = birthday;
		this.storeId = storeId;
	}
	public Pet(int id,String name,String typeName,Date birthday,int ownerId) {
		super();
		this.id = id;
		this.name = name;
		this.typeName = typeName;
		this.health = 1;
		this.love = 1;
		this.birthday = birthday;
		this.ownerId = ownerId;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the typeName
	 */
	public String getTypeName() {
		return typeName;
	}
	/**
	 * @param typeName the typeName to set
	 */
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	/**
	 * @return the health
	 */
	public int getHealth() {
		return health;
	}
	/**
	 * @param health the health to set
	 */
	public void setHealth(int health) {
		this.health = health;
	}
	/**
	 * @return the love
	 */
	public int getLove() {
		return love;
	}
	/**
	 * @param love the love to set
	 */
	public void setLove(int love) {
		this.love = love;
	}
	/**
	 * @return the birthday
	 */
	public Date getBirthday() {
		return birthday;
	}
	/**
	 * @param birthday the birthday to set
	 */
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	/**
	 * @return the ownerId
	 */
	public int getOwnerId() {
		return ownerId;
	}
	/**
	 * @param ownerId the ownerId to set
	 */
	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}
	/**
	 * @return the storeId
	 */
	public int getStoreId() {
		return storeId;
	}
	/**
	 * @param storeId the storeId to set
	 */
	public void setStoreId(int storeId) {
		this.storeId = storeId;
	}
	
}
