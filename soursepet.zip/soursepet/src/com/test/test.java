package com.test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class test {
	public static void main(String[] args) throws ParseException {
		String sd = "2002-05-23";
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Date birthday = null;
		birthday = format.parse(sd.toString());
		System.out.println(getType(birthday));
	}
	public static String getType(Object test) {
		return test.getClass().getName().toString();			
	}
}

