
package com.main;

import java.util.List;
import java.util.Scanner;

import com.bean.PetOwner;
import com.bean.PetStore;
import com.dao.PetOwnerDao;
import com.dao.PetStoreDao;
import com.dao.impl.PetOwnerDaoImpl;
import com.dao.impl.PetStoreDaoImpl;

public class MainPetStore {
	public static void main(String[] args) {
		startPetStore();
	}
	public static void startPetStore() {
		System.out.println("宠物商店启动");
		System.out.println("************************************************************");
		PetStoreDao petStoreDao = new PetStoreDaoImpl();
		List<PetStore> list = petStoreDao.getAllStore();
		for(int i = 0;i<list.size();i++) {
			PetStore store = list.get(i);
			System.out.println("第"+store.getId()+"个宠物商店，名字叫："+store.getName());
		}
		System.out.println("************************************************************");
		System.out.println();
		Scanner input = new Scanner(System.in);
		boolean type = true;
		int num;
		while(type) {
			System.out.print("请选择输入宠物商店信息操作系统模式，输入0为退出.1为添加.2为显示所有.3为修改.4为删除");
			num = input.nextInt();
			switch (num) {
			case 0:{
				System.out.println("************************************************************");
				System.out.println("退出宠物商店管理！");
				type = false;
				break;
			}
			case 1:{
				writeStore();
				break;
			}
			case 2:{
				readStore();
				break;
			}
			case 3:{
				updateStore();
				break;
			}
			case 4:{
				deleteStore();
				break;
			}
			default:{
				System.out.println("输入有误，请按照指定规则输入");
				type = true;
			}	
			}
		}
	}
	public static void writeStore() {
		Scanner input = new Scanner(System.in);
		System.out.print("请输入商店ID：");
		int id = input.nextInt();
		System.out.print("请输入商店姓名：");
		String name = input.next();
		System.out.print("请输入商店密码：");
		String pwd = input.next();
		System.out.print("请输入注入资金：");
		int balance = input.nextInt(); 
		PetStore petStore = new PetStore(id, name, pwd, balance);
		PetStoreDao petStoreDao = new PetStoreDaoImpl();
		int result = petStoreDao.insert(petStore);
		if(result==1) {
			System.out.println("恭喜您！开店成功！");
		}else {
			System.out.println("对不起，开店失败!");
		}
	}	
	public static void readStore() {
		PetStoreDao petStoreDao = new PetStoreDaoImpl();
		List<PetStore> list = petStoreDao.getAllStore();
		for (PetStore ps : list) {
			System.out.println("第"+ps.getId()+"个宠物商店，名字叫："+ps.getName()+"密码为："+ps.getPassword()+"，资金为："+ps.getBalance());
		}
		System.out.println("************************************************************");
	}
	public static void updateStore() {
		Scanner input = new Scanner(System.in);
		System.out.print("请输入要修改的商店ID：");
		int StoreId = input.nextInt();
		System.out.print("请输入资金：");
		int balance = input.nextInt();
		PetStore petStore = new PetStore(StoreId,balance);
		PetStoreDao petStoreDao = new PetStoreDaoImpl();
		int result = petStoreDao.modify(petStore);
		if(result==1) {
			System.out.println("恭喜您！修改商店资金成功！");
		}else {
			System.out.println("对不起，修改商店资金失败！");
		}
	}
	public static void deleteStore() {
		Scanner input = new Scanner(System.in);
		System.out.print("请输入要删除的商店ID：");
		int storeId = input.nextInt();
		PetStoreDao petStoreDao = new PetStoreDaoImpl();
		int result = petStoreDao.delete(storeId);
		if(result==1) {
			System.out.println("恭喜您！删除商店信息成功！");
		}else {
			System.out.println("对不起，删除商店信息失败！");
		}
	}
}

