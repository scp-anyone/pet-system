
package com.main;

import java.util.List;
import java.util.Scanner;

import com.bean.PetOwner;
import com.dao.PetOwnerDao;
import com.dao.impl.PetOwnerDaoImpl;

public class MainPetOwner {
	public static void main(String[] args) {
		startPetOwner();
	}
	public static void startPetOwner() {
		System.out.println("宠物商店启动");
		System.out.println("************************************************************");
		PetOwnerDao petOwnerDao = new PetOwnerDaoImpl();
		List<PetOwner> list = petOwnerDao.getAllOwner();
		for(int i = 0;i<list.size();i++) {
			PetOwner owner = list.get(i);
			System.out.println("第"+owner.getId()+"个宠物主人，名字叫："+owner.getName());
		}
		System.out.println("************************************************************");
		Scanner input = new Scanner(System.in);
		boolean type = true;
		int num;
		while(type) {
			System.out.print("请选择输入主人信息操作系统模式，输入0为退出.1为添加.2为显示所有.3为修改.4为删除");
			num = input.nextInt();
			switch (num) {
			case 0:{
				System.out.println("************************************************************");
				System.out.println("退出主人管理！");
				type = false;
				break;
			}
			case 1:{
				writeOwner();
				break;
			}
			case 2:{
				readOwner();
				break;
			}
			case 3:{
				updateOwner();
				break;
			}
			case 4:{
				deleteOwner();
				break;
			}
			default:{
				System.out.println("输入有误，请按照指定规则输入");
				type = true;
			}	
			}
		}
	}
	public static void writeOwner() {
		Scanner input = new Scanner(System.in);
		System.out.print("请输入主人ID：");
		int id = input.nextInt();
		System.out.print("请输入主人姓名：");
		String name = input.next();
		System.out.print("请输入主人密码：");
		String pwd = input.next();
		System.out.print("请输入主人元宝数：");
		int money = input.nextInt(); 
		PetOwner petOwner = new PetOwner(id,name,pwd,money);
		PetOwnerDao petOwnerDao = new PetOwnerDaoImpl();
		int result = petOwnerDao.insert(petOwner);
		if(result==1) {
			System.out.println("恭喜您！注册主人信息成功！");
		}else {
			System.out.println("对不起，注册失败!");
		}
	}
	public static void readOwner() {
		PetOwnerDao petOwnerDao = new PetOwnerDaoImpl();
		List<PetOwner> list = petOwnerDao.getAllOwner();
		for (PetOwner po : list) {
			System.out.println("第"+po.getId()+"个宠物主人，名字叫："+po.getName()+"密码为："+po.getPassword()+"，元宝数为："+po.getMoney());
		}
		System.out.println("************************************************************");
	}
	public static void updateOwner() {
		Scanner input = new Scanner(System.in);
		System.out.print("请输入要修改的主人ID：");
		int ownerId = input.nextInt();
		System.out.print("请输入元宝数：");
		int money = input.nextInt();
		PetOwner petOwner = new PetOwner(ownerId,money);
		PetOwnerDao petOwnerDao = new PetOwnerDaoImpl();
		int result = petOwnerDao.modify(petOwner);
		if(result==1) {
			System.out.println("恭喜您！修改主人元宝成功！");
		}else {
			System.out.println("对不起，修改主人元宝失败！");
		}
	}
	public static void deleteOwner() {
		Scanner input = new Scanner(System.in);
		System.out.print("请输入要删除的主人ID：");
		int ownerId = input.nextInt();
		PetOwnerDao petOwnerDao = new PetOwnerDaoImpl();
		int result = petOwnerDao.delete(ownerId);
		if(result==1) {
			System.out.println("恭喜您！删除主人ID成功！");
		}else {
			System.out.println("对不起，删除主人ID失败！");
		}
	}
	
}
	