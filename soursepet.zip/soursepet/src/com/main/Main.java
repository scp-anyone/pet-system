package com.main;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		startPetSystem();
	}
	public static void startPetSystem() {
		System.out.println(" 宠物商店启动");
		MainPetOwner.readOwner();
		MainPetStore.readStore();
		Scanner input = new Scanner(System.in);
		boolean type = true;
		int num;
		while(type) { 
			System.out.println("请选择输入登录模式，输入0为退出宠物系统."
					+ "1为主人管理.2为商店管理.3为主人登录.4为商店登录");
			num = input.nextInt();
			switch(num) {
			case 0:
			{
				System.out.println("************************************************************");
				System.out.println("谢谢您的光临！欢迎下次再见！");
				type = false;
				break;
			}
			case 1:{
				MainPetOwner.main(null);
				break;
			}
			case 2:{
				MainPetStore.main(null);
				break;
			}
			case 3:{
				MainPetOwnerLogin.main(null);
				break;
			}
			case 4:{
				MainPetStoreLogin.main(null);
				break;
			}
			default:{
				System.out.println("输入有误，请按照指定规则输入");
				type = true;
			}
			}
		}
	}
}
