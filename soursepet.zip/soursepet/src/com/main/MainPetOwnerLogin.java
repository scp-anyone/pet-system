
package com.main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.bean.Pet;
import com.bean.PetOwner;
import com.bean.PetStore;
import com.dao.PetDao;
import com.dao.impl.PetDaoImpl;
import com.service.PetOwnerService;
import com.service.PetService;
import com.service.PetStoreService;
import com.service.impl.PetOwnerServiceImpl;
import com.service.impl.PetServiceImpl;
import com.service.impl.PetStoreServiceImpl;

public class MainPetOwnerLogin {
	public static void main(String[] args) {
		loginOwner();
	}
	public static void loginOwner() {
			PetOwnerService petOwnerService = new PetOwnerServiceImpl();
			Scanner input = new Scanner(System.in);
			System.out.print("请输入您的ID：");
			int oid = input.nextInt();
			System.out.print("请输入您的密码：");
			String pwd = input.next();
			PetOwner petOwner = petOwnerService.login(oid, pwd);
			boolean reg = true;
			while(reg) {
				if(petOwner==null) {
					System.out.println("登录失败！");
					System.out.print("请输入您的ID：");
					oid = input.nextInt();
					System.out.print("请输入您的密码：");
					pwd = input.next();
					petOwnerService.login(oid, pwd);
					reg = true;
				}else {
					reg = false;
					int num;
					boolean type = true;
					while(type) {
						System.out.print("请选择输入操作模式，输入0为退出.1为领养新宠物.2为查看宠物");
						num = input.nextInt();
						switch (num) {
						case 0:
							System.out.println("************************************************************");
							System.out.println("退出用户登录！");
							type = false;
							break;
						case 1:
							getNewPet(petOwner);
							break;
						case 2:
							readPet(petOwner);
							break;
						case 3:
							break;
						case 4:
							break;
						default:
							System.out.println("输入有误，请按照指定规则输入");
							type = true;
						}
					}
			}
	}
			}
	private static void getNewPet(PetOwner petOwner) {
		// TODO Auto-generated method stub
		if(petOwner.getMoney()>=50) {
			Pet p = new Pet();
			
			Scanner input = new Scanner(System.in);
			System.out.print("请输入宠物ID：");
			int id = input.nextInt();
			System.out.print("请输入宠物姓名：");
			String name = input.next();
			System.out.println("请输入宠物类型：");
			String pwd = input.next();
			System.out.println("请输入宠物出生日期：");
			String sd = input.next();
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Date birthday = null;
			try {
				birthday = format.parse(sd.toString());
			} catch (ParseException e) {
				e.printStackTrace();
			}
			Pet pet = new Pet(id,name,pwd,birthday,petOwner.getId());
			PetService petService = new PetServiceImpl();
			petOwner.setMoney(petOwner.getMoney()-50);
			int result = petService.get(pet, petOwner);
			if(result == 1) {
				System.out.println("领养宠物成功！");
			}
			else {
				petOwner.setMoney(petOwner.getMoney()+50);
				System.out.println("对不起，培育宠物失败！");
			}
		}
		else {
			System.out.println("对不起，您的元宝不足，请充值");
		}
		
	}
	private static void readPet(PetOwner petOwner) {
		// TODO Auto-generated method stub
		PetDao petDao = new PetDaoImpl();
		List<Pet> list = petDao.getPetByOwnerId(petOwner.getId());
		System.out.println("************************************************************");
		for (Pet pet : list) {
			System.out.println("ID："+pet.getId()+"，名字："+pet.getName()+"，类型："+pet.getTypeName()+"，健康否："+pet.getHealth()+"，爱心："+pet.getLove()+"，出生日期："+pet.getBirthday());
			System.out.println("************************************************************");
		}
	}
}
