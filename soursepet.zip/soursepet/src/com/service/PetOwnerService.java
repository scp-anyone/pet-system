package com.service;

import com.bean.PetOwner;

public interface PetOwnerService {
	public  PetOwner login(int oid,String pwd);


}
