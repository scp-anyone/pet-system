
package com.service;

import com.bean.PetStore;

public interface PetStoreService {
	public PetStore login(int storeId,String pwd);
}
