
package com.service;

import java.util.List;

import com.bean.Pet;
import com.bean.PetOwner;
import com.bean.PetStore;

public interface PetService {
	public int breed(Pet pet,PetStore petstore);
	public List<Pet> getPetByStoreId(int storeId);
	public int get(Pet pet,PetOwner petowner);
	public List<Pet> getPetByOwnerId(int ownerId);
}
