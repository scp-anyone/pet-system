
package com.service.impl;

import com.bean.PetStore;
import com.dao.PetStoreDao;
import com.dao.impl.PetStoreDaoImpl;
import com.service.PetStoreService;


public class PetStoreServiceImpl implements PetStoreService{
	PetStoreDao petStoreDao = new PetStoreDaoImpl();
	@Override
	public PetStore login(int storeId, String pwd) {
		PetStore petStore = petStoreDao.getStoreById(storeId);
		if(petStore==null)
			return petStore;
		else if(!petStore.getPassword().equals(pwd)) {
			petStore = null;
		}
		return petStore;
	}

}
