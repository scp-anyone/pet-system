
package com.service.impl;

import java.util.List;
import com.bean.Pet;
import com.bean.PetOwner;
import com.bean.PetStore;
import com.dao.PetDao;
import com.dao.PetOwnerDao;
import com.dao.PetStoreDao;
import com.dao.impl.PetDaoImpl;
import com.dao.impl.PetOwnerDaoImpl;
import com.dao.impl.PetStoreDaoImpl;
import com.service.PetService;

public class PetServiceImpl implements PetService{
	PetDao petDao = new PetDaoImpl();
	PetStoreDao petStoreDao = new PetStoreDaoImpl();
	PetOwnerDao petOwnerDao = new PetOwnerDaoImpl();
	@Override
	public int breed(Pet pet, PetStore petstore) {
		int result = 0;
		int pet_result = petDao.insert(pet);
		int store_result = petStoreDao.modify(petstore);
		if(pet_result==1&&store_result==1) {
			result = 1;
		}
		return result;
	}
	@Override
	public List<Pet> getPetByStoreId(int storeId) {		
		return petDao.getPetByStoreId(storeId);
	}
	@Override
	public int get(Pet pet, PetOwner petowner) {
		// TODO Auto-generated method stub
		int result = 0;
		int pet_result = petDao.insert(pet);
		int store_result = petOwnerDao.modify(petowner);
		if(pet_result==1&&store_result==1) {
			result = 1;
		}
		return result;
	}
	@Override
	public List<Pet> getPetByOwnerId(int ownerId) {
		// TODO Auto-generated method stub
		return petDao.getPetByOwnerId(ownerId);
	}

}
