package com.service.impl;

import com.bean.PetOwner;
import com.dao.PetOwnerDao;
import com.dao.PetStoreDao;
import com.dao.impl.PetOwnerDaoImpl;
import com.service.PetOwnerService;

public class PetOwnerServiceImpl implements PetOwnerService{
	PetOwnerDao petOwnerDao= new PetOwnerDaoImpl();
	@Override
	public  PetOwner login(int oid, String pwd) {
		PetOwner petOwner = petOwnerDao.getOnwerById(oid);
		if(petOwner==null)
			return petOwner;
		else if(!petOwner.getPassword().equals(pwd)) {
			petOwner = null;
		}
		return petOwner;
	}

}
