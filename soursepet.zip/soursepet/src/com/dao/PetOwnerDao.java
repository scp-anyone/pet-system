
package com.dao;

import java.util.List;

import com.bean.PetOwner;

public interface PetOwnerDao {
	public PetOwner getOnwerById(int ownerId);
	public int insert(PetOwner petOwner);
	public int modify(PetOwner petOwner);
	public int delete(int ownerId);
	public List<PetOwner> getAllOwner();
}
