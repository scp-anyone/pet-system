
package com.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import com.bean.PetOwner;
import com.bean.PetStore;
import com.dao.BaseDao;
import com.dao.PetStoreDao;

public class PetStoreDaoImpl extends BaseDao implements PetStoreDao{

	@Override
	public PetStore getStoreById(int storeId) {
		PetStore petStore = null;
		@SuppressWarnings("unchecked")
		Map<Integer, PetStore> map = (HashMap<Integer, PetStore>) this.readObjectFromFile("PetStore.dat");
		if(map!=null) {
			petStore = map.get(storeId);
		}
		return petStore;
	}

	@SuppressWarnings("unchecked")
	@Override
	public int insert(PetStore petStore) {
		int result = 0;
		Map<Integer, PetStore> map = null;
		try {
			map = (HashMap<Integer,PetStore>) this.readObjectFromFile("PetStore.dat");
			if(map==null) {
				map = new HashMap<Integer,PetStore>();
			}
			map.put(petStore.getId(), petStore);
			this.writeObjectToFile(map, "PetStore.dat");
			result = 1;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
 
	@SuppressWarnings("unchecked")
	@Override
	public int modify(PetStore petStore) {
		int result = 0;
		Map<Integer, PetStore> map = null;
		try {
			map = (HashMap<Integer, PetStore>) this.readObjectFromFile("PetStore.dat");
			if(map!=null) {
				PetStore pStore = (PetStore)map.get(petStore.getId());
				pStore.setBalance(petStore.getBalance());
				map.put(pStore.getId(), pStore);
				this.writeObjectToFile(map, "PetStore.dat");
				result = 1;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	@Override
	public int delete(int storeId) {
		int result = 0;
		Map<Integer, PetStore> map = null;
		try {
			map = (HashMap<Integer, PetStore>) this.readObjectFromFile("PetStore.dat");
			if(map==null) {
				map = new HashMap<Integer, PetStore>();
			}
			if(map.containsKey(storeId)) {
				map.remove(storeId);
				result = this.writeObjectToFile(map, "PetStore.dat");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public List<PetStore> getAllStore() {
		List<PetStore> list = new ArrayList<PetStore>();
		@SuppressWarnings("unchecked")
		Map<Integer, PetStore> map = (HashMap<Integer, PetStore>)this.readObjectFromFile("PetStore.dat");
		if(map!=null) {
			for(Map.Entry<Integer, PetStore> entry : map.entrySet() ) {
				list.add(entry.getValue());
			}
		}else {
			System.out.println("文件不存在！请检查！");
		}
		return list;
	}

}
