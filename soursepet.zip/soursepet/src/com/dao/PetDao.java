
package com.dao;

import com.bean.Pet;
import java.util.*;

public interface PetDao {
	public int insert(Pet pet);
	public List<Pet> getPetByStoreId(int storeId);
	public List<Pet> getPetByOwnerId(int ownerId);
}
