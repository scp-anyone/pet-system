
package com.dao;

import java.util.List;

import com.bean.PetStore;

public interface PetStoreDao {
	public PetStore getStoreById(int storeId);
	public int insert(PetStore petStore);
	public int modify(PetStore petStore);
	public int delete(int storeId);
	public List<PetStore> getAllStore();
}
