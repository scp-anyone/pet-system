package ui;


import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.List;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.filechooser.FileNameExtensionFilter;

import com.bean.Pet;
import com.bean.PetOwner;
import com.bean.PetStore;
import com.dao.PetDao;
import com.dao.PetOwnerDao;
import com.dao.PetStoreDao;
import com.dao.impl.PetDaoImpl;
import com.dao.impl.PetOwnerDaoImpl;
import com.dao.impl.PetStoreDaoImpl;
import com.main.MainPetOwner;
import com.main.MainPetStore;
import com.service.PetOwnerService;
import com.service.PetService;
import com.service.PetStoreService;
import com.service.impl.PetOwnerServiceImpl;
import com.service.impl.PetServiceImpl;
import com.service.impl.PetStoreServiceImpl;
public class uimain extends JFrame implements  ActionListener
{
    private static final long serialVersionUID=-9077023825514749548L;
    private JTextArea ownerinquireshowText=new JTextArea();    
    private JTextArea storeinquireshowText=new JTextArea();   
    private JTextArea owner_login_inquireshowText=new JTextArea();    
    private JTextArea store_login_inquireshowText=new JTextArea();
    
    final JFrame frame=new JFrame();

    PetOwner petOwner1;    
    PetStore petStore1;
    
//菜单声明        
    final JMenuBar menuBar=new JMenuBar();    //创建菜单栏
    final JMenu ownermenu=new JMenu();    
    final JMenu storemenu=new JMenu();
    final JMenu loginmenu=new JMenu();
    final JMenu exitmenu=new JMenu(); 
    
    final JMenuItem menuownerregister=new JMenuItem();    
    final JMenuItem menuownerdelete=new JMenuItem();   
    final JMenuItem menuownerinquire=new JMenuItem(); 
    final JMenuItem menuownerchange=new JMenuItem();  
    final JMenuItem menustoreregister=new JMenuItem();   
    final JMenuItem menustoredelete=new JMenuItem();  
    final JMenuItem menustoreinquire=new JMenuItem();  
    final JMenuItem menustorechange=new JMenuItem();    
    final JMenuItem menuownerlogin=new JMenuItem();
    final JMenuItem menustorelogin=new JMenuItem();
    final JMenuItem exit=new JMenuItem();    
    
 

    


//标签声明
    JPanel uiownerregister=new JPanel();       
	JLabel w1= new JLabel("账户id");      JTextField b1=new JTextField(28);//创建文本框
    JLabel w2= new JLabel("账号姓名");    JTextField b2=new JTextField(28);//创建文本框
	JLabel w3= new JLabel("账户密码");    JTextField b3=new JTextField(28);//创建文本框
	JLabel w4= new JLabel("账户元宝");    JTextField b4=new JTextField(28);   JButton bt1=new JButton("确定");    //创建JButton对象
    JPanel uiownerdelete=new JPanel();
    JLabel w5 =new JLabel("账户id");   JTextField b5=new JTextField(28);    JButton bt2=new JButton("确定");    //创建JButton对象
    JPanel uiownerinquire=new JPanel();
    
    ///////////
    JPanel uiownerchange=new JPanel();
 	JLabel w6= new JLabel("账户id");    JTextField b6=new JTextField(28);    JButton bt3=new JButton("确定");    //创建JButton对象
 	JLabel w7= new JLabel("账户元宝修改为");    JTextField b7=new JTextField(28);//创建文本框
    JPanel uistoreregister=new JPanel();
	JLabel w8= new JLabel("商店id");    JTextField b8=new JTextField(28);//创建文本框
	JLabel w9= new JLabel("商店名称");    JTextField b9=new JTextField(28);//创建文本框
	JLabel w10= new JLabel("商店密码");    JTextField b10=new JTextField(28);//创建文本框
	JLabel w11= new JLabel("商店元宝");    JTextField b11=new JTextField(28);   JButton bt4=new JButton("确定");    //创建JButton对象
	JPanel uistoredelete=new JPanel();
    JLabel w12 =new JLabel("商店id");    JTextField b12=new JTextField(28);    JButton bt5=new JButton("确定");    //创建JButton对象
	JPanel uistoreinquire=new JPanel();
    ///////////
    JPanel uistorechange=new JPanel();
 	JLabel w13= new JLabel("商店id");    JTextField b13=new JTextField(28);//创建文本框
 	JLabel w14= new JLabel("商店元宝修改为");   JTextField b14=new JTextField(28);    JButton bt6=new JButton("确定");    //创建JButton对象
    JPanel uiownerlogin=new JPanel();
 	JLabel w15= new JLabel("账户id");        JTextField b15=new JTextField(28);//创建文本框
	JLabel w16= new JLabel("账户密码");    JTextField b16=new JTextField(28);    JButton bt7=new JButton("登录");    //创建JButton对象
    JPanel uistorelogin=new JPanel();
	JLabel w17= new JLabel("商店id");  JTextField b17=new JTextField(28);//创建文本框
	JLabel w18= new JLabel("商店密码");    JTextField b18=new JTextField(28);    JButton bt8=new JButton("登录");    //创建JButton对象
    JPanel uiownerlogin_choice=new JPanel();
    JButton bt11=new JButton("领养宠物");    //创建JButton对象																				
    JButton bt12=new JButton("查看宠物");    //创建JButton对象
    ///////////
    JPanel uiownerlogin_choice_adopt=new JPanel();
	JLabel w19 =new JLabel("宠物id");    JTextField b19=new JTextField(28);
    JLabel w20 =new JLabel("宠物姓名");    JTextField b20=new JTextField(28);
    JLabel w21 =new JLabel("宠物类型");    JTextField b21=new JTextField(28);
    JLabel w22 =new JLabel("宠物生日");    JTextField b22=new JTextField(28);    JButton bt9=new JButton("确定");    //创建JButton对象
    JPanel uiownerlogin_choice_inquire=new JPanel();
    //////////
    JPanel uistorelogin_choice=new JPanel();
    JButton bt13=new JButton("培育宠物");    //创建JButton对象																				
    JButton bt14=new JButton("查看宠物");    //创建JButton对象
    //////////
    JPanel uistorelogin_choice_breed=new JPanel();
    JLabel w23 =new JLabel("宠物id");    JTextField b23=new JTextField(28);
    JLabel w24 =new JLabel("宠物名字");    JTextField b24=new JTextField(28);
    JLabel w25 =new JLabel("宠物名字");    JTextField b25=new JTextField(28);
    JLabel w26 =new JLabel("宠物健康");    JTextField b26=new JTextField(28);
    JLabel w27 =new JLabel("宠物爱心");    JTextField b27=new JTextField(28);
    JLabel w28 =new JLabel("宠物生日");    JTextField b28=new JTextField(28);    JButton bt10=new JButton("确定");    //创建JButton对象
    JPanel uistorelogin_choice_inquire=new JPanel();
    /////////
    
    JPanel cards=new JPanel(new CardLayout()); //卡片式布局的面板
    CardLayout uishow;
    JPanel uimain=new JPanel();   
    
    
    
    
    public static void main(String[] args)
    {
        new uimain();
 
    }   
    public uimain()
    {
		MainPetOwner.readOwner();
		MainPetStore.readStore();
		
	    final JScrollPane scrollPane1=new JScrollPane(); //创建滚动面板
	    scrollPane1.add(ownerinquireshowText);

//菜单标题添加menubar       
        ownermenu.setText("主人账号管理");    //为文件菜单设置标题
        menuBar.add(ownermenu);    //把文件菜单添加到菜单栏上
        storemenu.setText("商店账号管理");    //为编辑菜单设置标题
        menuBar.add(storemenu);//把编辑菜单添加到菜单栏上
        loginmenu.setText("登录");
        menuBar.add(loginmenu);
        exitmenu.setText("退出");
        menuBar.add(exitmenu);		
//宠物主人菜单 
		menuownerregister.setText("注册");    //设置复制菜单项的标题
		ownermenu.add(menuownerregister);    //把复制菜单项添加到编辑菜单

		menuownerdelete.setText("注销");    //设置复制菜单项的标题
		ownermenu.add(menuownerdelete);    //把复制菜单项添加到编辑菜单

		menuownerinquire.setText("查询");    //设置复制菜单项的标题
		ownermenu.add(menuownerinquire);    //把复制菜单项添加到编辑菜单

		menuownerchange.setText("修改");    //设置复制菜单项的标题
		ownermenu.add(menuownerchange);    //把复制菜单项添加到编辑菜单
		        


		        
//宠物商店菜单        
		menustoreregister.setText("注册");    //设置复制菜单项的标题
		storemenu.add(menustoreregister);    //把复制菜单项添加到编辑菜单
		menustoredelete.setText("注销");    //设置剪切菜单项的标题
		storemenu.add(menustoredelete);    //把剪切菜单项添加到编辑菜单
		menustoreinquire.setText("查询");    //设置粘贴菜单项的标题
		storemenu.add(menustoreinquire);    //把粘贴菜单项添加到编辑菜单
		menustorechange.setText("修改");    //设置粘贴菜单项的标题
		storemenu.add(menustorechange);    //把粘贴菜单项添加到编辑菜单
		        
//登录菜单
		menuownerlogin.setText("主人登录");
	    loginmenu.add(menuownerlogin);
	    menustorelogin.setText("商店登录");
		loginmenu.add(menustorelogin);
		//ownerlogin_adopt
		        
		        
//退出菜单
		exit.setText("退出");
		exitmenu.add(exit);
		   


		

//uimain
    	//创建一个图标
    	ImageIcon img=new ImageIcon("D:\\emo.png");
    	JLabel j=new JLabel(img);
    	uimain.add(j);
//宠物主人ui具体实现
    	//uiownerregister        

    	uiownerregister.add(w1);  
        uiownerregister.add(b1);
    	uiownerregister.add(w2);  
        uiownerregister.add(b2);
    	uiownerregister.add(w3);  
        uiownerregister.add(b3);
    	uiownerregister.add(w4);  
        uiownerregister.add(b4);
        uiownerregister.add(bt1);
        //uiownerdelete
         uiownerdelete.add(w5);
         uiownerdelete.add(b5);          
         uiownerdelete.add(bt2);
        //uiownerinquire

         uiownerinquire.add(ownerinquireshowText);
        //文本域        
         //uiownerchange
     	uiownerchange.add(w6);  
        uiownerchange.add(b6);
     	uiownerchange.add(w7);  
        uiownerchange.add(b7);  
        uiownerchange.add(bt3);

        
        
 
//宠物商店ui具体实现
    	//uistoreregister       
    	uistoreregister.add(w8);  
        uistoreregister.add(b8);
        uistoreregister.add(w9);  
        uistoreregister.add(b9);
    	uistoreregister.add(w10);  
        uistoreregister.add(b10);
    	uistoreregister.add(w11);  
        uistoreregister.add(b11);     
        uistoreregister.add(bt4);
        //uistoredelete
         uistoredelete.add(w12);
         uistoredelete.add(b12);  
         uistoredelete.add(bt5);
		//uistoreinquire
        //文本域
        uistoreinquire.add(storeinquireshowText);

     	uistorechange.add(w13);  
        uistorechange.add(b13);
     	uistorechange.add(w14);  
        uistorechange.add(b14);          
        uistorechange.add(bt6);
//登录ui具体实现
        //uiowner
    	uiownerlogin.add(w15);  
        uiownerlogin.add(b15);
    	uiownerlogin.add(w16);  
        uiownerlogin.add(b16);       
        uiownerlogin.add(bt7);

        //uistore
    	uistorelogin.add(w17);  
        uistorelogin.add(b17);
    	uistorelogin.add(w18);  
        uistorelogin.add(b18);
        uistorelogin.add(bt8);     

        //uiownerlogin_choice
        uiownerlogin_choice.add(bt11);
        uiownerlogin_choice.add(bt12);
        
    	//uiownerlogin_adopt
		uiownerlogin_choice_adopt.add(w19);  
		uiownerlogin_choice_adopt.add(b19);
		uiownerlogin_choice_adopt.add(w20);  
		uiownerlogin_choice_adopt.add(b20); 
		uiownerlogin_choice_adopt.add(w21);  
		uiownerlogin_choice_adopt.add(b21);
		uiownerlogin_choice_adopt.add(w22);  
		uiownerlogin_choice_adopt.add(b22);
		uiownerlogin_choice_adopt.add(bt9);
		//uiownerlogin_inquire
		uiownerlogin_choice_inquire.add(owner_login_inquireshowText);

		
		//uistorelogin_choice
		uistorelogin_choice.add(bt13);
		uistorelogin_choice.add(bt14);
		
		//uiownerlogin_breed
		uistorelogin_choice_breed.add(w23);  
		uistorelogin_choice_breed.add(b23); 
		uistorelogin_choice_breed.add(w24);  
		uistorelogin_choice_breed.add(b24);
		uistorelogin_choice_breed.add(w25);  
		uistorelogin_choice_breed.add(b25);
		uistorelogin_choice_breed.add(w26);  
		uistorelogin_choice_breed.add(b26); 
		uistorelogin_choice_breed.add(w27);  
		uistorelogin_choice_breed.add(b27);
		uistorelogin_choice_breed.add(w28);  
		uistorelogin_choice_breed.add(b28);
		uistorelogin_choice_breed.add(bt10);
		//uistorelogin_choice_inquire
		uistorelogin_choice_inquire.add(store_login_inquireshowText);
		
        
//面板添加    
        cards=new JPanel(new CardLayout());
        cards.add(uimain,"uimain");    //向卡片式布局面板中添加面板1
        cards.add(uiownerregister,"uiownerregister");    //向卡片式布局面板中添加面板2
        cards.add(uiownerdelete,"uiownerdelete"); 
        cards.add(uiownerinquire,"uiownerinquire"); 
        cards.add(uiownerchange,"uiownerchange"); 
        cards.add(uistoreregister,"uistoreregister"); 
        cards.add(uistoredelete,"uistoredelete"); 
        cards.add(uistoreinquire,"uistoreinquire"); 
        cards.add(uistorechange,"uistorechange"); 
        cards.add(uiownerlogin,"uiownerlogin");
        cards.add(uistorelogin,"uistorelogin");
        cards.add(uiownerlogin_choice,"uiownerlogin_choice");
        cards.add(uistorelogin_choice,"uistorelogin_choice");
        cards.add(uiownerlogin_choice_adopt,"uiownerlogin_choice_adopt"); 
        cards.add(uiownerlogin_choice_inquire,"uiownerlogin_choice_inquire"); 
        cards.add(uistorelogin_choice_breed,"uistorelogin_choice_breed");
        cards.add(uistorelogin_choice_inquire,"uistorelogin_choice_inquire");
        uishow=(CardLayout)(cards.getLayout());
        
        
        

        
//添加监听
        menuownerregister.addActionListener(this);
        menuownerdelete.addActionListener(this);
        menuownerinquire.addActionListener(this);
        menuownerchange.addActionListener(this);
        menustoreregister.addActionListener(this);
        menustoredelete.addActionListener(this);
        menustoreinquire.addActionListener(this);
        menustorechange.addActionListener(this);
        menuownerregister.addActionListener(this);
        menustoreregister.addActionListener(this);
        menuownerlogin.addActionListener(this);
        menustorelogin.addActionListener(this);
        bt1.addActionListener(this);
        bt2.addActionListener(this);
        bt3.addActionListener(this);
        bt4.addActionListener(this);
        bt5.addActionListener(this);
        bt6.addActionListener(this);
        bt7.addActionListener(this);
        bt8.addActionListener(this);
        bt9.addActionListener(this);
        bt10.addActionListener(this);
        bt11.addActionListener(this);
        bt12.addActionListener(this);
        bt13.addActionListener(this);
        bt14.addActionListener(this);
        exit.addActionListener(this);        
        
        
        
//frame设置        
        frame.setTitle("宠物管理系统");    //设置窗体标题
        frame.setBounds(200,150,350,400);    //设置窗体位置和大小
//        frame.add(panel);
        frame.setJMenuBar(menuBar);    //把菜单栏放到窗体上
//        panel.setBackground(Color.blue);    //设置背景色   
        frame.add(cards);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);    //设置窗体默认关闭方式
        frame.setVisible(true);
        
        
        uishow.show(cards,"uimain");    //调用show()方法显示面板1
        
        
        
//        final JToolBar toolBar=new JToolBar();    //创建工具栏
//        getContentPane().add(toolBar,BorderLayout.NORTH);    //把工具栏放到窗体上方
//        final JButton btn_open=new JButton();    //创建工具按钮
//        btn_open.addActionListener(new ActionListener()
//        {
//            //添加动作监听器
//            public void actionPerformed(final ActionEvent arg0)
//            {
////                openTextFile();    //调用方法，操作文件
//            }
//        });
//        btn_open.setText("  打  开  ");    //设置工具按钮的标题
//        toolBar.add(btn_open);    //把工具按钮添加到工具栏上
//        final JButton btn_exit=new JButton();    //创建工具按钮
//        btn_exit.addActionListener(new ActionListener()
//        {
//            //添加动作监听器
//            public void actionPerformed(final ActionEvent arg0)
//            {
//                System.exit(0);    //退出系统
//            }
//        });
//        btn_exit.setText("  退  出  ");    //设置工具按钮的标题
//        toolBar.add(btn_exit);    //把工具按钮添加到工具栏上
//        final JTabbedPane tabbedPane=new JTabbedPane();    //创建选项卡面板
//        getContentPane().add(tabbedPane,BorderLayout.CENTER);    //把选项卡面板放到窗体中央
//        final JScrollPane scrollPane1=new JScrollPane();    //创建滚动面板
//        //把滚动面板放到选项卡的第一个选项页
//        tabbedPane.addTab("文件的属性",null,scrollPane1,null);
//        ta_showProperty=new JTextArea();    //创建文本域
//        //把文本域添加到滚动面板的视图中
//        scrollPane1.setViewportView(ta_showProperty);
//        final JScrollPane scrollPane2=new JScrollPane();    //创建滚动面板
//        //把滚动面板放到选项卡的第二个选项页
//        tabbedPane.addTab("文件的内容",null,scrollPane2,null);
//        ta_showText=new JTextArea();    //创建文本域
//        //把文本域添加到滚动面板的视图中
//        scrollPane2.setViewportView(ta_showText);
    	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO 自动生成的方法存根
		if(e.getSource()==menuownerregister) {
			uishow.show(cards,"uiownerregister");    //调用show()方法显示面板2
		}
		else if(e.getSource()==menuownerdelete) {
			uishow.show(cards,"uiownerdelete"); 
		}
		else if(e.getSource()==menuownerinquire) {
			uishow.show(cards,"uiownerinquire");
			PetOwnerDao petOwnerDao = new PetOwnerDaoImpl();
			List<PetOwner> list = petOwnerDao.getAllOwner();
			for (PetOwner po : list) {
				ownerinquireshowText.append("第"+po.getId()+"个宠物主人，名字叫："+po.getName()+"密码为："+po.getPassword()+"，元宝数为："+po.getMoney()+'\n');
			}
	        ownerinquireshowText.setBounds(200,150,350,350);

		}
		else if(e.getSource()==menuownerchange) {
			uishow.show(cards,"uiownerchange"); 
		}
		else if(e.getSource()==menustoreregister) {
			uishow.show(cards,"uistoreregister"); 
		}
		else if(e.getSource()==menustoredelete) {
			uishow.show(cards,"uistoredelete"); 
		}
		else if(e.getSource()==menustoreinquire) {
			uishow.show(cards,"uistoreinquire");
			PetStoreDao petStoreDao = new PetStoreDaoImpl();
			List<PetStore> list = petStoreDao.getAllStore();
			for (PetStore ps : list) {
				storeinquireshowText.append("第"+ps.getId()+"个宠物商店，名字叫："+ps.getName()+"密码为："+ps.getPassword()+"，资金为："+ps.getBalance()+'\n');
			}
	        storeinquireshowText.setBounds(200,150,350,350);
		}
		else if(e.getSource()==menustorechange) {
			uishow.show(cards,"uistorechange"); 
		}
		
		else if(e.getSource()==menuownerlogin) {
			uishow.show(cards,"uiownerlogin"); 
		}
		else if(e.getSource()==menustorelogin) {
			uishow.show(cards,"uistorelogin"); 
		}
		else if(e.getSource()==bt1) {
			PetOwner petOwner = new PetOwner(Integer.parseInt(b1.getText()),b2.getText(),b3.getText(),Integer.parseInt(b4.getText()));
			PetOwnerDao petOwnerDao = new PetOwnerDaoImpl();
			int result = petOwnerDao.insert(petOwner);
			if(result==1)
				JOptionPane.showMessageDialog(uiownerregister,"注册用户账号成功!","提示",1);
			else
				JOptionPane.showMessageDialog(uiownerregister,"对不起，注册失败!","错误 ",0);
		}
		else if(e.getSource()==bt2) {
			PetOwnerDao petOwnerDao = new PetOwnerDaoImpl();
			int result = petOwnerDao.delete(Integer.parseInt(b5.getText()));
			if(result==1) {
				JOptionPane.showMessageDialog(uiownerdelete,"恭喜您!删除主人ID成功!","提示",1);
			}else {
				JOptionPane.showMessageDialog(uiownerdelete,"对不起，删除主人ID失败!","错误 ",0);
			}
		}
		else if(e.getSource()==bt3) {
			PetOwner petOwner = new PetOwner(Integer.parseInt(b6.getText()),Integer.parseInt(b7.getText()));
			PetOwnerDao petOwnerDao = new PetOwnerDaoImpl();
			int result = petOwnerDao.modify(petOwner);
			if(result==1) {
				JOptionPane.showMessageDialog(uiownerchange,"恭喜您!修改主人元宝成功!","提示",1);
			}else {
				JOptionPane.showMessageDialog(uiownerchange,"对不起，修改主人元宝失败!","错误 ",0);
			}
		}
		else if(e.getSource()==bt4) {
			PetStore petStore = new PetStore(Integer.parseInt(b8.getText()),b9.getText(),b10.getText(),Integer.parseInt(b11.getText()));
			PetStoreDao petStoreDao = new PetStoreDaoImpl();
			int result = petStoreDao.insert(petStore);
			if(result==1)
				JOptionPane.showMessageDialog(uistoreregister,"注册用户账号成功!","提示",1);
			else
				JOptionPane.showMessageDialog(uistoreregister,"对不起，注册失败!","错误 ",0);
		}
		else if(e.getSource()==bt5) {
			PetStoreDao petStoreDao = new PetStoreDaoImpl();
			int result = petStoreDao.delete(Integer.parseInt(b12.getText()));
			if(result==1) {
				JOptionPane.showMessageDialog(uistoredelete,"恭喜您！删除商店信息成功!","提示",1);
			}else {
				JOptionPane.showMessageDialog(uistoredelete,"对不起，删除商店信息失败!","错误 ",0);
			}
		}
		else if(e.getSource()==bt6) {
			PetStore petStore = new PetStore(Integer.parseInt(b13.getText()),Integer.parseInt(b14.getText()));
			PetStoreDao petStoreDao = new PetStoreDaoImpl();
			int result = petStoreDao.modify(petStore);
			if(result==1) {
				System.out.println("恭喜您！修改商店资金成功！");
			}else {
				System.out.println("对不起，修改商店资金失败！");
			}
		}
		else if(e.getSource()==bt7) {
			PetOwnerService petOwnerService = new PetOwnerServiceImpl();
			PetOwner petOwner = petOwnerService.login(Integer.parseInt(b15.getText()),b16.getText());
			if(petOwner==null) {
				JOptionPane.showMessageDialog(uiownerlogin,"用户名或密码错误！","错误 ",0);
			}
			else {
				JOptionPane.showMessageDialog(uiownerlogin,"登录成功!","提示",1);
				petOwner1=petOwner;
				uishow.show(cards, "uiownerlogin_choice");
			}
		}
		else if(e.getSource()==bt8) {
			PetStoreService petStoreService = new PetStoreServiceImpl();
			PetStore petStore = petStoreService.login(Integer.parseInt(b17.getText()),b18.getText());
			if(petStore==null) {
				JOptionPane.showMessageDialog(uistorelogin,"用户名或密码错误！","错误 ",0);
			}
			else {
				JOptionPane.showMessageDialog(uistorelogin,"登录成功","提示",1);
				uishow.show(cards, "uistorelogin_choice");
				petStore1=petStore;
			}
		}
		else if(e.getSource()==bt9) {

			String sd=b22.getText();
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Date birthday = null;
			try {
				birthday = format.parse(sd.toString());
			} catch (ParseException e1) {
				e1.printStackTrace();
			}
			Pet pet = new Pet(Integer.parseInt(b19.getText()),b20.getText(),b21.getText(),birthday,petOwner1.getId());
			PetService petService = new PetServiceImpl();
			petOwner1.setMoney(petOwner1.getMoney()-50);
			int result = petService.get(pet, petOwner1);
			if(result == 1) {
				JOptionPane.showMessageDialog(uiownerlogin_choice_adopt,"领养宠物成功!","提示",1);
			}
			else {
				petOwner1.setMoney(petOwner1.getMoney()+50);
				JOptionPane.showMessageDialog(uiownerlogin_choice_adopt,"对不起，培育宠物失败!","错误 ",0);
			}
		}
		else if(e.getSource()==bt10) {
			if(petStore1.getBalance()>=50) {
			String sd=b28.getText();
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Date birthday = null;
			try {
				birthday = format.parse(sd.toString());
			} catch (ParseException e1) {
				e1.printStackTrace();
			}
			Pet pet = new Pet(Integer.parseInt(b23.getText()),b24.getText(),b25.getText(),Integer.parseInt(b26.getText()),Integer.parseInt(b27.getText()),birthday,petStore1.getId());
			PetService petService = new PetServiceImpl();
			petStore1.setBalance(petStore1.getBalance()-50);
			int result = petService.breed(pet, petStore1);
			if(result == 1) {
				JOptionPane.showMessageDialog(uiownerlogin_choice_adopt,"恭喜您！培育宠物成功！","提示",1);
			}
			else {
				petOwner1.setMoney(petOwner1.getMoney()+50);
				JOptionPane.showMessageDialog(uiownerlogin_choice_adopt,"对不起，培育宠物失败!","错误 ",0);
			}}
			else {
				JOptionPane.showMessageDialog(uiownerlogin_choice_adopt,"对不起，您的资金不足，请充值!","提示",1);
			}
		}
		else if(e.getSource()==bt11) {
			uishow.show(cards, "uiownerlogin_choice_adopt");
		}
		else if(e.getSource()==bt12) {
			uishow.show(cards, "uiownerlogin_choice_inquire");
			PetDao petDao = new PetDaoImpl();
			List<Pet> list = petDao.getPetByOwnerId(petOwner1.getId());
			for (Pet pet : list) {
				owner_login_inquireshowText.append("ID："+pet.getId()+"，名字："+pet.getName()+"，类型："+pet.getTypeName()+"，健康否："+pet.getHealth()+"，爱心："+pet.getLove()+"，出生日期："+pet.getBirthday()+'\n');
			}
		}
		else if(e.getSource()==bt13) {
			uishow.show(cards, "uistorelogin_choice_breed");
		}
		else if(e.getSource()==bt14) {
			uishow.show(cards, "uistorelogin_choice_inquire");
			PetDao petDao = new PetDaoImpl();
			List<Pet> list = petDao.getPetByStoreId(petStore1.getId());
			for (Pet pet : list) {
				store_login_inquireshowText.append("ID："+pet.getId()+"，名字："+pet.getName()+"，类型："+pet.getTypeName()+"，健康否："+pet.getHealth()+"，爱心："+pet.getLove()+"，出生日期："+pet.getBirthday());
			}
		}	
		else if(e.getSource()==exit) {
            System.exit(0);    //退出系统
		}
	}
	
	
	
	
}




